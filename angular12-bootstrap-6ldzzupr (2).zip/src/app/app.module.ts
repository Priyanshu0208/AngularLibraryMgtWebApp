import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { HttpClientModule } from '@angular/common/http';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AppRoutingModule } from './app-routing.module';
import { AppserviceService } from './services/appservice.service';
import { GetBooksService } from './services/get-books.service';
import { HeaderComponent } from './header/header.component';
import { BorrowBooksComponent } from './borrow-books/borrow-books.component';
import { AuthServiceService } from './services/auth-service.service';
import { ReturnBooksComponent } from './return-books/return-books.component';
import { AdminModule } from './admin/admin.module';

@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    AdminModule,
    NgbModule,
    HttpClientModule,
  ],
  declarations: [
    AppComponent,
    LoginPageComponent,
    DashboardComponent,
    HeaderComponent,
    ReturnBooksComponent,
    BorrowBooksComponent,
  ],
  bootstrap: [AppComponent],
  providers: [AppserviceService, GetBooksService, AuthServiceService],
})
export class AppModule {}
