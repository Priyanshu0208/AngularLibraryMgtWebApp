import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from '../services/auth-service.service';
import { AppserviceService } from '../services/appservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  isLoggedIn: boolean = false;
  constructor(
    private authServiceService: AuthServiceService,
    private appserviceService: AppserviceService,
    private router: Router
  ) {
    this.authServiceService.getIsLoggedIn$().subscribe((status) => {
      this.appserviceService.isLoggedIn = status;
      this.isLoggedIn = this.appserviceService.isLoggedIn;
    });
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  logout(): void {
    this.authServiceService.logout();
    this.router.navigate(['/login']);
    // localStorage.removeItem('token');
    //this.isLoggedInSubject.next(false);
  }
}
