import { HttpClient } from '@angular/common/http';
import { error } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { AuthServiceService } from '../services/auth-service.service';
import { AppserviceService } from '../services/appservice.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css'],
})
export class LoginPageComponent implements OnInit {
  loginForm: FormGroup;
  isSubmitted = false;
  formError = false;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authServiceService: AuthServiceService,
    private appserviceService: AppserviceService
  ) {}
  ngOnInit() {
    this.loginForm = this.fb.group({
      email: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
      adminCheckbox: new FormControl(''),
    });
  }
  onSubmit() {
    this.isSubmitted = true;
    if (this.loginForm.valid) {
      const user: { email; password } = this.loginForm.value;
      // console.log('Login credentials:', user.email, user.password);
      //If we Authticate user throw API call
      // this.http.post('http://localhost:3000/projects', user).subscribe(response => {
      //   console.log('Login successfull', response);
      // } ,(error) =>{
      //   console.log('Error', error);
      // } );
      this.authServiceService
        .login(user.email, user.password)
        .subscribe((response) => {
          console.log('login=' + response);
          if (response) {
            if (this.loginForm.get('adminCheckbox')?.value) {
              console.log('admin login');
              this.router.navigate(['/admin']);
            } else {
              this.router.navigate(['/dashboard']);
            }
          } else {
            console.log(error);
            this.formError = true;
          }
        });
    }
  }
  googleLogin() {
    console.log('google with login');
  }
}
