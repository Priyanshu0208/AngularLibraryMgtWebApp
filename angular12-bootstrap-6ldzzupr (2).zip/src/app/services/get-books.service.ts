import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppserviceService } from './appservice.service';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Injectable({
  providedIn: 'root',
})
export class GetBooksService {
  books;
  constructor(
    private http: HttpClient,
    private appservice: AppserviceService
  ) {}
  private availableBooks = new BehaviorSubject<any[]>([]);
  private borrowedBooks = new BehaviorSubject<any[]>([]);
  availableBooks$ = this.availableBooks.asObservable();
  borrowedBooks$ = this.borrowedBooks.asObservable();

  loadBooks() {
    this.http.get<any[]>('assets/books.json').subscribe(
      (data) => {
        this.availableBooks.next(data);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  borrowBook(bookId: number) {
    const books = this.availableBooks.value;
    const borrowed = this.borrowedBooks.value;
    const index = books.findIndex(book => book.id === bookId);
    if (index !== -1) {
      const [book] = books.splice(index, 1);
      borrowed.push(book);
      this.availableBooks.next(books);
      this.borrowedBooks.next(borrowed);
    }
  } 
  ngOnInit(): void {}
  getBooks() {
    //console.log(this.appservice.getAvailableBooks());
    if (!this.appservice.getAvailableBooks.length) {
      this.http.get<any[]>('assets/books.json').subscribe(
        (data) => {
          //console.log(JSON.stringify(data, null, 2));
          this.appservice.setAvailableBooks(JSON.stringify(data));
         // console.log(this.appservice.getAvailableBooks());
        },
        (error) => {
          console.log(error);
        }
      );
    }
  }
}
