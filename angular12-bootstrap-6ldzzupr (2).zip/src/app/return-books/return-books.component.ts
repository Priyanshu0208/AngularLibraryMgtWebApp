import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return-books',
  templateUrl: './return-books.component.html',
  styleUrls: ['./return-books.component.css']
})
export class ReturnBooksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}